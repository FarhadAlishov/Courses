%For Plotting with the chirpZ-transform
%----ALTERED FOR USE IN SIMULINK arm2.mdl file-------
%Must specify sequence's original sampling freq, the freq of interest
%to you (becomes center freq) and the freq span you want to investigate
%the span cannot be such that center+span/2 > sampfreq/2 or you'll see
%sillyness

function y = plotzsim(sequence) 

plotnum = sequence(end);
span = sequence(end-1);
frequency = sequence(end-2);
sampfreq = sequence(end-3);
sequence = sequence(1:end-4);
%sequence = sequence(ceil(length(sequence)*(3/4))+1 : end);


M = length(sequence);
time = [0:(1/sampfreq):(M-1)*(1/sampfreq)];
figure(plotnum)
subplot(2,1,1)
plot(time, sequence)
title('Signal vs. Relative Time (Secs)')
initf = exp(j*2*pi*(frequency - floor(span/2))/sampfreq);
stepf = exp(-j*2*pi*(span/M)/sampfreq);

% disp('initfangle:') 
% disp(angle(initf))
% disp('stepfangle:') 
% disp(angle(stepf))

x= [angle(initf):-1*angle(stepf):angle(initf)-(angle(stepf)*(M-1))];
x = x*sampfreq/(2*pi);
y = czt(sequence, M, stepf, initf);
figure(plotnum)
subplot(2,1,2)
plot(x, abs(y)/M)
title('Signal vs. Frequency (Hz)')
axis tight
hold on

y = 1;

return;