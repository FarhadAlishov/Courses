%For Plotting with the chirpZ-transform
%----ALTERED FOR USE IN SIMULINK arm2.mdl file-------
%Must specify sequence's original sampling freq, the freq of interest
%to you (becomes center freq) and the freq span you want to investigate
%the span cannot be such that center+span/2 > sampfreq/2 or you'll see
%sillyness

function y2 = plotzsim3(sequence) 

plotnum2 = sequence(end);
span2 = sequence(end-1);
frequency2 = sequence(end-2);
sampfreq2 = sequence(end-3);
sequence2 = sequence(1:end-4);
%sequence2 = sequence2(ceil(length(sequence2)*(3/4)) + 1 : end);

M2 = length(sequence2);
time2 = [0:(1/sampfreq2):(M2-1)*(1/sampfreq2)];
figure(plotnum2)
subplot(2,1,1)
plot(time2, sequence2)
title('Signal vs. Relative Time (Sec)')
initf2 = exp(j*2*pi*(frequency2 - floor(span2/2))/sampfreq2);
stepf2 = exp(-j*2*pi*(span2/M2)/sampfreq2);

% disp('initfangle:') 
% disp(angle(initf2))
% disp('stepfangle:') 
% disp(angle(stepf2))

x2 = [angle(initf2):-1*angle(stepf2):angle(initf2)-(angle(stepf2)*(M2-1))];
x2 = x2*sampfreq2/(2*pi);
y2 = czt(sequence2, M2, stepf2, initf2);
figure(plotnum2)
subplot(2,1,2)
plot(x2, abs(y2)/M2)
title('Signal vs. Frequency (Hz)')
axis tight
hold on
y2 = 1;

return;